1. client, server and endpoint 指代的是调用消息类型函数或处理消息类型函数时的规则
2. client hello, server hello等是在生成消息类型时要遵守的规则
3. 规则和规则之间用空行分割
4. 

目前想法：一个是从服务器和客户端角度来思考，一个是从消息类型角度思考
- 服务器和客户端角度思考放第一篇论文：FUZZ不一致
    - 无需生成消息类型的规则（收到xx报文应该怎么做）
    [收到的消息类型][]规则
    
    - 客户端服务器也是需要通过消息类型来确定自己的规则（发送xx报文应该怎么做）
    [][发送的消息类型]规则

    - [收到的消息类型][发送的消息类型]规则接收和发送都相关的规则

    - [][]规则表示不依赖消息类型，比如可能是一些计算内容
- 消息类型角度思考放第二篇论文：静态代码分析检测上（反汇编和状态机匹配）/放第一篇也行
    - 如果放第一篇：
        - 了解状态机，知道xx消息类型的发送和接受时。客户端和服务器处在那个状态（上下文信息）
        - xx消息类型在发送和接受时应该注意什么
    - 如果放第二篇：RFC->状态机<-反汇编代码 箭头表示做map
        - 借助消息类型和函数摘要确定反汇编代码在状态机的位置
        - 实现精准fuzz，针对函数级别的fuzz（如何泛化？）
如果没有表现出强倾向性与那个消息类型，就不会记录在那个消息类型下的规则

消息类型角度已经涉及到具体的消息类型了,只有[server/client][server/client]，前一个代表受到,后一个代表发出
大模型看到规则应该能构造出违反规则的实例数据包或实例上下文，不能构造出的就不是规则

RFC8446中的文档内容应该包括什么内容：
1. 对TLS宏观介绍
2. 具体的要求，所有的具体要求应该都是规则


更新：[收到][发出]，如果没有就是空,有多个用/来表示

1. 难点：规则的划分方法，如何将复杂的规则划分到状态机里，怎么定义这些规则才能方便使用
方法：如上；

2. 
难点：对于RFC文档是由不同的人编写的，编写习惯不一致，编写时都有自己的规范性语言，模型如何快速掌握这种规范性语言并理解，如何做二次升级，例如学习了TLS1.2如何快速理解TLS1.3
技术：使用fineturing/RAG对模型做微调，使模型能够理解描述协议的规范性语言（第三章内容）
例如：opaque mandatory<300..400>;
            /* length field is two bytes, cannot be empty */
In the following example, "mandatory" is a vector that must contain
   between 300 and 400 bytes of type opaque.  It can never be empty.
   The actual length field consumes two bytes, a uint16, which is
   sufficient to represent the value 400

当前规则：重动作轻状态=>优化方向加入状态
[]：和发出报文不相关
!表示没收到或者不该

显式规则：关键词
隐式规则：
情态动词(can may),
条件(if,when),
其他动词(contain),
in general,
In particular
It is expected
are permitted to
the same
need
will
only
always
unless

1.状态应该有abort和keep connection，后续二次优化数据集考虑
2.当前数据集问题：对于一些!和[]的情况写的不好，存在一条规则实际上包括两件事的情况
3.对于消息和扩展应该在熟读RFC之后进行优化，尽量总结标准化的消息和扩展
4.对于未定义的错误处理应该有一种正规的方式进行处理
5.存在大量规则+特例的形式，应该引入条件
6.对于规则应该也有划分，有些规则没法构造反例就应该放弃:
Any future values that are allocated must ensure that the transmitted
   protocol messages unambiguously identify which mode was selected by
   the server; at present, this is indicated by the presence of the
   "key_share" in the ServerHello.

Future extensions MUST define their interaction with 0-RTT.
7.规则中含有一部分需要引用的内容，应该妥善利用大模型的检索能力:
If any of these checks fail, the server MUST NOT respond with the
   extension and must discard all the first-flight data using one of the
   first two mechanisms listed above (thus falling back to 1-RTT or
   2-RTT).

8.有一些规则的反例没有那么好构造：
[][]If the server chooses to accept the "early_data" extension, then it
   MUST comply with the same error-handling requirements specified for
   all records when processing early data records.
这里是要把所有的processing都构造出来吗?

9.应该让大模型微调或者RAG学会的东西:
The "extension_data" field of this extension contains a
   "PreSharedKeyExtension" value:
      struct {
          opaque identity<1..2^16-1>;
          uint32 obfuscated_ticket_age;
      } PskIdentity;
      opaque PskBinderEntry<32..255>;
      struct {
          PskIdentity identities<7..2^16-1>;
          PskBinderEntry binders<33..2^16-1>;
      } OfferedPsks;
      struct {
          select (Handshake.msg_type) {
              case client_hello: OfferedPsks;
              case server_hello: uint16 selected_identity;
          };
      } PreSharedKeyExtension;
   identity:  A label for a key.  For instance, a ticket (as defined in
      Appendix B.3.4) or a label for a pre-shared key established
      externally.
   obfuscated_ticket_age:  An obfuscated version of the age of the key.
      Section 4.2.11.1 describes how to form this value for identities
      established via the NewSessionTicket message.  For identities
      established externally, an obfuscated_ticket_age of 0 SHOULD be
      used, and servers MUST ignore the value.
   identities:  A list of the identities that the client is willing to
      negotiate with the server.  If sent alongside the "early_data"
      extension (see Section 4.2.10), the first identity is the one used
      for 0-RTT data.
   binders:  A series of HMAC values, one for each value in the
      identities list and in the same order, computed as described
      below.
   selected_identity:  The server's chosen identity expressed as a
      (0-based) index into the identities in the client's list.

10.否则的话规则:
[][]certificate_request_context:  If this message is in response to a
      CertificateRequest, the value of certificate_request_context in
      that message.  Otherwise (in the case of server authentication),
      this field SHALL be zero length.

11.Servers MAY send data after sending their first flight, but
       because the handshake is not yet complete, they have no assurance
       of either the peer's identity or its liveness (i.e., the
       ClientHello might have been replayed).
实现时的差异

需要一个process方法标记一些规则是处理信息并不是发送信息，对于发送信息的定义是另一个实体不是自己
[[]][]定义给自己处理实体